
// this file is overwritten by `npm run build:pre`
const version = 'master';
export default version;
