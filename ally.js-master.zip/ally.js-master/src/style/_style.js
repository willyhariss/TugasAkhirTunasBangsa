
// exporting modules to be included the UMD bundle

import focusSource from './focus-source';
import focusWithin from './focus-within';
export default {
  focusSource,
  focusWithin,
};
