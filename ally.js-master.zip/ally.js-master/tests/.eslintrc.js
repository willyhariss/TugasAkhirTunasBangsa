
module.exports = {
  "extends": "../.eslintrc.js",
  "env": {
    "amd": 1,
    "browser": 1,
    "es6": 0,
    "node": 0
  },
  "rules": {
    "no-var": 0,
    "no-const-assign": 0,
    "prefer-const": 0
  }
};
