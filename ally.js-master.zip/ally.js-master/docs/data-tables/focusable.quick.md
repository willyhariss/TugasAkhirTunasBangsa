
# Focusable elements - strategy:quick - ally.js compatibility table

This placeholder-document is replaced by `npm run build:data-tables` in the `dist` directory.

[See this table on the website](https://allyjs.io/docs/data-tables/focusable.quick.html)
