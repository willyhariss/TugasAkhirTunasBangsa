---
layout: doc-api.html
tags: argument-list
---

# ally.is.focusable

Determines if an element is considered focusable.


## Description

An element is considered focusable if it is [`ally.is.focusRelevant`](./focus-relevant.md), [`ally.is.visible`](./visible.md) and not [`ally.is.disabled`](./disabled.md).

Consult the data tables [what browsers consider focusable](../../data-tables/focusable.md) and [what ally.js fails to consider focusable](../../data-tables/focusable.is.md) to learn how HTML elements behave.


## Usage

```js
var element = document.getElementById('victim');
var isFocusable = ally.is.focusable(element);
```

### Arguments

| Name | Type | Default | Description |
| ---- | ---- | ------- | ----------- |
| element | [`HTMLElement`](https://developer.mozilla.org/en/docs/Web/API/HTMLElement) | *required* | The Element to test. |

The underlying rules can also be accessed in the [`options` argument style](../concepts.md#single-options-argument) by calling `ally.is.focusable.rules(options)`:

| Name | Type | Default | Description |
| ---- | ---- | ------- | ----------- |
| context | [`<selector>`](../concepts.md#selector) | *required* | The element to examine. The first element of a collection is used. |
| except | [`<focus identification exception>`](../concepts.md#focus-identification-exceptions) | `{}` | The Element to test. |

### Returns

Boolean, `true` if the element is focusable.

### Throws

[`TypeError`](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/TypeError) if `element` argument is not of type `HTMLElement`.


## Examples


## Changes

* Since `v1.1.0` all `<area>` elements are considered focus-relevant, but only valid `<area>` elements are considered focusable.
* Since `v1.1.0` exceptions can be passed to `ally.is.focusable.rules(options)`.
* Since `v1.1.0` the state of the `<iframe>` or `<object>` element in which the currently examined element is hosted in is considered.
* Since `v1.1.0` hidden `<object>` elements are focusable in Chrome - [Blink 586191](https://code.google.com/p/chromium/issues/detail?id=586191).


## Notes

See [`ally.is.focusRelevant`](./focus-relevant.md#notes)


## Related resources

* [`ally.is.focusRelevant`](focus-relevant.md) is used to identify elements that can receive focus
* [`ally.is.focusable`](focusable.md) identifies elements that are focusable
* [`ally.query.focusable`](../query/focusable.md) finds focusable elements in the DOM
* [`ally.is.validArea`](valid-area.md) is used to identify if `<area>` elements satisfy the requirements to be considered focusable

* [What Browsers Consider Focusable](../../data-tables/focusable.md)
* [What ally.js fails to consider focusable](../../data-tables/focusable.is.md)


## Contributing

* [module source](https://github.com/medialize/ally.js/blob/master/src/is/focusable.js)
* [document source](https://github.com/medialize/ally.js/blob/master/docs/api/is/focusable.md)
* [unit test](https://github.com/medialize/ally.js/blob/master/test/unit/is.focusable.test.js)

